SELECT CategoryName,num,avg_price,min_price,max_price,sum_order
FROM (
    SELECT CategoryName,count(CategoryName) as num,round(avg(UnitPrice),2) as avg_price,
            min(UnitPrice)as min_price,max(UnitPrice) as max_price,sum(UnitsOnOrder) as sum_order
    FROM Product,Category
    WHERE Product.CategoryId == Category.Id
    group by CategoryName
)
WHERE num > 10