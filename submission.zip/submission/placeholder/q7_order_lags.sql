select Id,OrderDate,PreviousOrderDate,
    round(Cast ((JulianDay(OrderDate) - JulianDay(PreviousOrderDate)) As float),2)
from (  SELECT [Order].Id as Id,OrderDate,
            LAG(OrderDate,1,OrderDate) over(order by OrderDate)PreviousOrderDate
        FROM Customer, [Order]
        WHERE Customer.Id = [Order].CustomerId and [Order].CustomerId = "BLONP"
        order by OrderDate
        limit 10)
order by OrderDate