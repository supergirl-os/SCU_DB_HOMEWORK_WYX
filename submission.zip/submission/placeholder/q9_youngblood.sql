select RegionDescription, FirstName, LastName,max(BirthDate)
from Employee,EmployeeTerritory,Territory,Region 
where Employee.Id = EmployeeTerritory.EmployeeId 
and EmployeeTerritory.TerritoryId = Territory.Id 
and Territory.RegionId = Region.Id 
group by RegionDescription
order by Region.Id