-- 使用了判断语句，BelongPlace用来表示是否属于北美
-- limit 20放在order下面，用来输出结果的前20个
-- 从15445开始，就是要让Id大于15445
SELECT Id,ShipCountry,
       CASE WHEN ShipCountry == 'USA' or ShipCountry == 'Mexico' or ShipCountry == 'Canada'
       THEN 'NorthAmerica'
       ELSE 'OtherPlace'
       END AS BelongPlace
FROM [Order]
WHERE Id>=15445
order by Id
limit 20