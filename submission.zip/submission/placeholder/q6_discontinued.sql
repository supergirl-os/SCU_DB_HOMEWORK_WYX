-- 可以使用min建一个新表，再进行查询
-- 是在8个停产的产品中查询
SELECT new.ProductName,new.CompanyName,new.ContactName
FROM (  SELECT ProductName,min(OrderDate),CompanyName,ContactName 
        FROM Customer,[Order],OrderDetail, Product,Category
        WHERE Customer.Id = [Order].CustomerId 
            and [Order].Id = OrderDetail.OrderId 
            and OrderDetail.ProductId = Product.Id 
            and Product.CategoryId = Category.Id
            and Product.Discontinued = 1
        group by ProductName) new
order by ProductName

