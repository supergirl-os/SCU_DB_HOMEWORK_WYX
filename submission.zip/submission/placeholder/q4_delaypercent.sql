-- cast转换数据类型
-- group by 是按照名字分组
-- 做成新表，对新表进行运算，若直接在select加子查询，无法对应相除

SELECT late.name,
       Round(cast(late.num as float)*100.00/cast(total.num as float),2) as percentage
FROM (  select CompanyName as name , count(CompanyName)as num 
        from [order],Shipper 
        where [order].ShipVia == Shipper.Id group by CompanyName) total,
     (  select CompanyName as name, count(CompanyName)as num 
        from [order],Shipper 
        where [order].ShipVia == Shipper.Id and ShippedDate > RequiredDate 
        group by CompanyName) late
where late.name == total.name
order by percentage desc