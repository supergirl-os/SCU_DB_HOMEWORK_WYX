-- 使用instr获取“-”所在位置，substring获取“-”前的所有字符；
-- distinct用来唯一输出ShipName；
-- order是数据库关键字，要用[order]来索引

select distinct ShipName,substr(ShipName,1,instr(ShipName,'-')-1) 
from [Order] 
where ShipName like '%-%' order by ShipName;