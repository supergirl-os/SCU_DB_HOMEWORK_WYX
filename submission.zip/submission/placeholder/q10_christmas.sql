-- 使用了CTE,但是出来的结果无法排序，可能是没有设置ID，但是设置之后，呈现一直在循环，
-- 跑不出结果来。于是直接使用group_concat，结果打印出来
SELECT group_concat(ProductName,',') 
FROM (  SELECT ProductName
        FROM Customer,[Order],OrderDetail, Product,Category
        WHERE Customer.Id = [Order].CustomerId 
        and [Order].Id = OrderDetail.OrderId 
        and OrderDetail.ProductId = Product.Id 
        and Product.CategoryId = Category.Id
        and CompanyName =="Queen Cozinha" 
        and OrderDate like '%2014-12-25%'
        order by Product.Id)